package com.demo.SpringMVCBoot.controller;

import org.springframework.ui.ModelMap;


public interface UserRegistrationController {
	public String getLoginForm(ModelMap model);
}
